gcloud ml vision detect-text test.jpg > gcloudRead.txt
